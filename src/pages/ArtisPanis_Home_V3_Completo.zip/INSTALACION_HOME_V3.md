# Artis Panis · Inicio v3

## Archivos

- `Home_Liquid_Glass_V3_Cotizaciones_Top3_Tiempo.tsx`: sustituye el contenido de tu página `Home.tsx`.
- `markets_api.mjs`: ruta HTTP necesaria para consultar los índices bursátiles de forma segura **desde el servidor**.

## 1. Instala la ruta de cotizaciones

Tu web ya consume rutas propias como `/api/leaderboard`. Añade `/api/markets` en el **mismo backend**.

### Si utilizas Express

Copia `markets_api.mjs` a la carpeta de tu servidor, por ejemplo `server/markets_api.mjs`, y en el archivo que crea `app` registra esta ruta **antes** del fallback que entrega la página React:

```js
import { marketQuotesHandler } from './markets_api.mjs';

app.get('/api/markets', marketQuotesHandler);
```

Ajusta la ruta de importación si lo guardas en otra carpeta. Necesitas Node.js 18 o superior (recomendado Node 20/22) porque usa `fetch` y `AbortSignal.timeout` nativos.

### Si despliegas funciones serverless Node.js

Puedes usar `marketQuotesHandler` como función exportada por defecto: `export default marketQuotesHandler`. Comprueba la convención de nombres y carpetas de tu proveedor para publicar `/api/markets`. En Vercel, por ejemplo, se puede usar el archivo `api/markets.js` con este contenido (y con el módulo original accesible desde la carpeta correspondiente):

```js
import handler from '../server/markets_api.mjs';
export default handler;
```

El backend debe estar publicado en **el mismo dominio** que la web, o el proxy de desarrollo debe redirigir `/api` a dicho backend.

## 2. Comprueba el endpoint

Abre `https://TU-DOMINIO/api/markets` o prueba:

```bash
curl -i http://localhost:3000/api/markets
```

Resultado previsto si Yahoo Finance responde:

```json
{
  "source": "Yahoo Finance · datos indicativos (fuente no oficial)",
  "fetchedAt": "2026-10-11T12:00:00.000Z",
  "status": "ok",
  "quotes": {
    "ibex": { "price": 13000, "change": 0.5, "currency": "EUR", "timestamp": "2026-10-10T15:30:00.000Z" },
    "nikkei": { "price": 40000, "change": -0.2, "currency": "JPY", "timestamp": "2026-10-10T06:00:00.000Z" }
  },
  "stale": false
}
```

**Estos números son un ejemplo del formato JSON, no cotizaciones reales.**

El frontend actualiza la consulta cada 2 minutos y ofrece un botón manual. El backend cachea durante 2 minutos y, si falla temporalmente, puede exponer por un máximo de 15 minutos la última respuesta con `stale: true` y fecha de origen. PANEX 75 se conserva como **índice ficticio, sin inventar cotizaciones**.

**Limitación:** Yahoo Finance v8/chart es una interfaz **no oficial**, con posibilidad de limitaciones, bloqueos o cambios y condiciones de uso que deben revisarse si se publica comercialmente. Para un servicio público crítico conviene contratar un proveedor con licencia y disponibilidad garantizada. No podemos certificar el acceso desde tu hosting sin desplegar allí el backend.

## 3. Ranking

Se conecta a `/api/leaderboard` usando `top5` y los mismos campos del componente `Level.tsx` (`posicion`, `username`, `level`, `total_xp`, `id`, `avatar`). **La clasificación debe estar accesible desde `/level`**, como en tu Header. Si falla, mostrará un estado de error y permitirá reintentar, sin poner usuarios ficticios.

## 4. Meteorología

No requiere backend ni clave adicional: se conecta a Open-Meteo con las seis coordenadas ya configuradas. Pantopía tiene una tarjeta de observatorio, sensación térmica, humedad, viento y una previsión a tres días. Las otras cinco regiones se presentan en tarjetas meteorológicas. Botón de actualización manual y refresco automático de 10 minutos.

## 5. Compatibilidad y verificación

Se mantienen el Header, Footer, Supabase TVP, canciones y metadatos, anuncios y concursos. Las tipografías están controladas para evitar el efecto de `font-size-adjust:1` del CSS global. Se comprobaron la sintaxis TSX y el layout de las nuevas secciones en anchuras de 320, 360, 390, 768, 1024, 1280 y 1536 px. Faltan la compilación del proyecto completo y una prueba end-to-end en tu servidor.
