/**
 * Artis Panis · /api/markets
 * Compatible with Express (app.get(..., marketQuotesHandler)) and Node serverless.
 * No API keys. Runs on the SERVER, never in the browser.
 * Source: Yahoo Finance chart endpoint (unofficial: uptime / licensing not guaranteed).
 * Cache: 2 minutes. Does not invent values or promise real-time quotes.
 */

const SYMBOLS = Object.freeze({ ibex: "^IBEX", nikkei: "^N225" });
const CACHE_MS = 120_000;
const STALE_MS = 15 * 60_000;
let cached = null;
let cachedAt = 0;
let pending = null;

function validNumber(value) {
  return typeof value === "number" && Number.isFinite(value);
}

async function fetchIndex(symbol) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=1d&range=5d`;
  const response = await fetch(url, {
    headers: {
      Accept: "application/json",
      "User-Agent": "Mozilla/5.0 (compatible; ArtisPanisMarketDashboard/1.0)",
    },
    signal: AbortSignal.timeout(8_000),
  });
  if (!response.ok) throw new Error(`Proveedor HTTP ${response.status} para ${symbol}`);
  const payload = await response.json();
  const info = payload?.chart?.result?.[0]?.meta;
  if (!info) throw new Error(`No hay metadatos para ${symbol}`);
  const price = info.regularMarketPrice;
  const previousClose = info.previousClose ?? info.chartPreviousClose;
  if (!validNumber(price) || price <= 0 || !validNumber(previousClose) || previousClose <= 0) {
    throw new Error(`Cotización incompleta para ${symbol}`);
  }
  // Variación diaria basada en el cierre anterior (no entre el primer y último día del rango).
  const change = ((price - previousClose) / previousClose) * 100;
  const seconds = info.regularMarketTime;
  return {
    price,
    change: Number(change.toFixed(3)),
    currency: typeof info.currency === "string" ? info.currency : "",
    timestamp: validNumber(seconds) ? new Date(seconds * 1000).toISOString() : null,
  };
}

async function getMarketData() {
  const now = Date.now();
  if (cached && now - cachedAt < CACHE_MS) return { ...cached, stale: false };
  if (pending) return pending;
  pending = (async () => {
    const results = await Promise.allSettled([fetchIndex(SYMBOLS.ibex), fetchIndex(SYMBOLS.nikkei)]);
    const quotes = {
      ibex: results[0].status === "fulfilled" ? results[0].value : null,
      nikkei: results[1].status === "fulfilled" ? results[1].value : null,
    };
    const available = Number(Boolean(quotes.ibex)) + Number(Boolean(quotes.nikkei));
    if (!available) {
      for (const result of results) if (result.status === "rejected") console.warn("Mercados:", result.reason?.message || result.reason);
      if (cached && now - cachedAt < STALE_MS) return { ...cached, stale: true };
      return null;
    }
    const payload = {
      source: "Yahoo Finance · datos indicativos (fuente no oficial)",
      fetchedAt: new Date(now).toISOString(),
      status: available === 2 ? "ok" : "partial",
      quotes,
    };
    cached = payload;
    cachedAt = now;
    return { ...payload, stale: false };
  })();
  try { return await pending; }
  finally { pending = null; }
}

export async function marketQuotesHandler(req, res) {
  if (req.method && req.method !== "GET") {
    res.setHeader("Allow", "GET");
    return res.status(405).json({ error: "Método no permitido" });
  }
  res.setHeader("Cache-Control", "public, max-age=60, stale-while-revalidate=30");
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  try {
    const data = await getMarketData();
    if (!data) return res.status(503).json({ status: "offline", quotes: { ibex: null, nikkei: null }, error: "No hay cotizaciones disponibles" });
    return res.status(200).json(data);
  } catch (error) {
    console.error("API Mercados:", error);
    return res.status(503).json({ status: "offline", quotes: { ibex: null, nikkei: null }, error: "Servicio temporalmente no disponible" });
  }
}

export default marketQuotesHandler;
