# Estado Paniense — Carpeta 4.0 (Vercel)

Este paquete amplía la Carpeta 3.0 con un rediseño Liquid Glass y cambios de backend. **NO reemplaces tu `server.js`**: la copia incluida es idéntica a la de Carpeta 3.0. Tampoco sustituyas tu `vercel.json` si ya has aplicado el ajuste de la función Python de Registro Civil.

## Archivos que debes actualizar

1. `src/pages/Carpeta.tsx` — sustituye el componente de Carpeta por `Carpeta.tsx` de este ZIP. Si en tu repositorio está en otra ruta, conserva la que ya tengas.
2. `citizenRoutes.js` — sustitúyelo en la **raíz**, junto a tu `server.js` existente. Utiliza tu sesión JWT, el mismo Supabase y el montaje `/api/citizen` que ya funciona.
3. **No toques** `api/registro_civil.py`, `api/registro_certificado.py` ni la configuración de Registro Civil que ya funciona.
4. Ejecuta `sql/003_fotos_perfil_storage.sql` en el SQL Editor de Supabase. Este script crea el bucket público de fotos **carpeta-cantantes**, con límite de 2 MB. Solo tu backend usa la clave de servicio para subir imágenes. Si el bucket ya existe, se actualizan los límites.
5. Haz push a GitHub para desplegar en Vercel. El `vercel.json` existente no precisa cambios para las nuevas rutas: empiezan por `/api/citizen` y se atienden en `server.js`.

## RMNeue

La Carpeta utiliza `font-family: "RMNeue", "RM Neue", ...` en todos sus elementos, incluidos botones y encabezados. **Las fuentes tipográficas no se distribuyen** en este paquete. Si RMNeue ya está cargada globalmente en el sitio, se aplicará directamente. Si no, carga **tu copia autorizada** de RMNeue desde la hoja de estilos de tu aplicación con un `@font-face` que apunte a tus propios archivos existentes (ejemplo: `/fonts/RMNeue-Regular.woff2`). Comprueba el nombre `font-family` definido en tu web.

## Novedades

- Términos de interfaz unificados como **Estado Paniense**; los valores de nombres de rol almacenados en Discord no se alteran.
- Liquid Glass: transparencias, reflejos sutiles, bordes claros, sombras suaves solo en tarjetas (sin sombras raras en botones), móvil/tablet/escritorio.
- Gráfica de XP bajo el nivel: consulta `/api/citizen/progress` y muestra cuánto falta para el siguiente nivel. Se prioriza el objetivo real si la tabla `user_levels` tiene campos habituales como `xp_required`, `next_level_xp`, `xp_para_subir`, etc. También admite dos variables de Vercel: `PANIENSE_XP_BASE` y `PANIENSE_XP_FACTOR`, aplicando **objetivo = base + factor × nivel actual** si es la fórmula del bot. Si no se conoce, la gráfica **marca claramente «aprox.»** y utiliza una estimación provisional. Para que sea exacta, compárteme la fórmula de niveles del bot.
- **Carpetas públicas**: pestaña `Otras carpetas` + buscador por username de Discord, rutas `GET /api/citizen/directory` y `GET /api/citizen/public/:id`. Requiere que quien consulta haya iniciado sesión y verificado su propio DPI. Solo ciudadanos con DPI verificado aparecen en búsquedas. La respuesta pública contiene únicamente nombre de usuario, avatar, nivel y favoritos; no hace consultas públicas al DPI o a economía, documentos, familia ni fechas de nacimiento.
- **Transferir por nombre de usuario**: en Rotomi, busca, elige y confirma un perfil real. El backend resuelve el ID, valida el DPI del destinatario y la función SQL cambia la propiedad de `public.capturas` dentro de una transacción atómica. Se sigue mostrando al destinatario antes de confirmar.
- **Foto de cantante desde el dispositivo**: ya no se pide pegar URLs. Acepta JPG, PNG y WebP de hasta 2 MB, comprueba cabeceras reales del archivo y lo sube a Supabase Storage a través de `/api/citizen/profile/image`. La imagen elegida se puede mostrar en carpetas públicas; informa a tus ciudadanos de que esa foto es pública.

## Error 503 en las transferencias Pokémon

El código anterior ya convertía el error **PGRST202/42883** en HTTP 503 si no encontraba la función SQL `transferir_captura_paniense`. **No significa que hayamos confirmado que esa es la causa de tu error**, ya que no contamos con los logs reales de producción.

1. En Supabase > SQL Editor, ejecuta primero `sql/COMPROBAR_ESQUEMA.sql`. Confirma que `capturas.id` es un identificador único entero o bigint y que `discord_id` contiene el dueño actual.
2. Ejecuta `sql/004_diagnostico_transferencias.sql`. Comprueba que la función **`transferir_captura_paniense(p_capture_id bigint, p_sender_id text, p_recipient_id text)`** existe y tiene permiso `service_role`.
3. Si no existe, y el esquema de `capturas` es compatible, ejecuta `sql/001_rotomi_transferencias.sql`. Si no tienes `capturas.id`, revisa `sql/002_SOLO_SI_CAPTURAS_NO_TIENE_ID.sql` *solo después de confirmar que hace falta*. Haz copia de seguridad antes de cualquier migración.
4. Despliega de nuevo en Vercel. Si persiste el 503, abre **Vercel > Logs** para `/api/citizen/pokemon/transfer` y busca `[Carpeta Ciudadana]`; envíame ese mensaje y podremos identificar la causa exacta sin suponer.

## Seguridad y comprobaciones

- `SUPABASE_SERVICE_KEY` y `JWT_SECRET` van **solo en Vercel**, nunca en el código del navegador.
- La URL pública de Storage contiene la foto elegida; nunca fotografías privadas. Tu usuario debe tener derecho a publicar la imagen.
- El directorio omite campos sensibles **desde el servidor**; no basta con ocultarlos en React.
- `/api/citizen/*` exige cookie de Discord verificada, origen de misma web en modificaciones y DPI propio válido.
- Comprobaciones locales: sintaxis JS de `server.js` y `citizenRoutes.js`, sintaxis TSX con el compilador TypeScript, equivalencia de `server.js` y `vercel.json` con Carpeta 3.0. **No se han ejecutado peticiones contra tu Supabase real ni un despliegue en Vercel.**
