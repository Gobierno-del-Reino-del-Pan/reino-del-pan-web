# Reino del Pan — Carpeta Ciudadana 3.0 (Vercel)

Esta entrega responde a la captura y a los errores de consola compartidos. **No se ha alterado ni una línea del `server.js` integrado anteriormente**. Se incluye exactamente la misma versión para comodidad; si ya tienes `server.js` de Carpeta 2.0, NO necesitas reemplazarlo. Solo se actualizan `Carpeta.tsx` y `citizenRoutes.js`, más los scripts SQL que precises.

## Instalar en el repositorio conectado con Vercel

- `Carpeta.tsx` → sustituye tu componente actual de la carpeta (normalmente `src/pages/Carpeta.tsx`). Conserva su ubicación si tu proyecto utiliza otra.
- `citizenRoutes.js` → raíz, junto a `server.js` (reemplaza SOLO este módulo del paquete anterior).
- `server.js` → **sin cambios respecto a Carpeta 2.0**. No necesitas volver a instalarlo si ya estabas usando la versión integrada.
- `api/registro_civil.py`, `api/registro_certificado.py` → misma carpeta `api/` en raíz, junto a `server.js` y `package.json`.
- `api/src/reg.png`, `api/src/gob.png` → copia los PNG reales de `public/reg.png` y `public/gob.png`. Los PNG no vienen en el ZIP porque no fueron adjuntados.
- `requirements.txt` → en raíz; si ya tienes uno, fusiona las dos dependencias, sin borrar las existentes.
- `public/rotomi.png` → debe seguir en la carpeta pública; no ha sido adjuntado.

## Cambios visuales

1. Cabecera compacta: tipografía controlada y márgenes para evitar que el título tape el subtítulo.
2. Perfil de Discord, roles (con alternativa visual si falla el icono) y Pokémon favorito juntos en la zona principal superior. Si no hay Pokémon favorito, aparece Rotomi.
3. DNI ficticio paniense a la derecha y **dinero total (efectivo + banco) justo debajo del nivel**. Los puntos base permanecen visibles.
4. El dinero y los puntos se leen desde `/api/citizen/economy`, una ruta autenticada que consulta el mismo `users_economy` y `usuarios` del proyecto. Esto evita depender de políticas de lectura del cliente público Supabase.
5. Mejores ajustes para tablet/móvil. Imágenes de adjuntos efímeros de Discord muestran alternativas en lugar de solicitar enlaces expirados.
6. Terminología: **PANIENSE**. Se ha cambiado asimismo la nueva función SQL de transferencias a `transferir_captura_paniense`.

## Error `/api/citizen/pokemon` — HTTP 500

El código anterior consultaba las columnas `id` y `created_at` explícitamente y hacía `order('created_at')`. El bot Pokémon **sí** escribe `discord_id`, `pokemon_id`, `pokemon_name`, `level`, `is_shiny`, `ball_used`, pero el código del bot suministrado no acredita que existan `id` y `created_at`. Si faltan, Supabase falla con 42703 y el router devuelve 500.

**Ahora GET `/pokemon` usa `select('*')` sin ordenar en la base de datos**, filtra por el ID de Discord autenticado y normaliza las columnas disponibles. Los Pokémon pueden verse aunque `created_at` o `id` no existan. Para *transferir* sí se necesita `capturas.id` como identificador **numérico único**. Si falta, el botón de transferencia aparece deshabilitado, con explicación.

Ve a Supabase > SQL Editor y ejecuta **primero** `sql/COMPROBAR_ESQUEMA.sql`. Si `capturas` no tiene columna `id`, evalúa `sql/002_SOLO_SI_CAPTURAS_NO_TIENE_ID.sql` (opcional, con copia de seguridad); si ya tiene `id`, NO lo ejecutes. Para habilitar las transferencias, ejecuta `sql/001_rotomi_transferencias.sql` — tras confirmar el tipo de `capturas.id` y que coincide con `bigint`. El RPC ahora se llama `transferir_captura_paniense`. Si ya ejecutaste la versión vieja de ese SQL, aplica el SQL nuevo; no altera propietarios ni borra capturas.

Si sigue apareciendo el 500 en `/pokemon`, abre Vercel > Logs de la función Node y busca `[Carpeta Ciudadana]`: puede deberse a otra causa, como falta de tabla, permisos o proyecto Supabase incorrecto. No podemos comprobar tus tablas sin acceso a ellas.

## Error `/api/registro_certificado?...` — HTTP 404

La integración mantiene el **motor original** `crear_pdf()` de ReportLab, pero necesita que Vercel publique la función Python `api/registro_certificado.py`. Vercel documenta las funciones Python en archivos dentro de `/api`.

**Prueba indispensable**: abre `https://TU-DOMINIO/api/registro_certificado?numero=RC-PRUEBA-000001` **sin sesión**. Si la función está publicada, debe responder `401` en JSON (tras comprobar el formato), NO un 404. Si devuelve 404, comprueba:

1. Que **`api/registro_certificado.py` está en la raíz del repositorio utilizado realmente por Vercel**, y no en `src/api`, `public/api` ni el directorio equivocado de un monorepo.
2. Que `requirements.txt` incluye `reportlab` y `PyJWT`.
3. Que tus rewrites, routes o build settings de `vercel.json` permiten llegar a `/api/registro_certificado` como función Python. Un rewrite genérico de `/api/(.*)` hacia Node/SPA puede atraparla.
4. En Vercel > Deployments > el último despliegue > Functions, comprueba si figura `api/registro_certificado.py`.

**No se incluye un `vercel.json` nuevo:** no tenemos el tuyo, y sustituirlo a ciegas podría romper tus rutas de Discord o el resto del backend. Compártelo y se adaptarán sus reglas añadiendo las mínimas excepciones.

Si la ruta empieza a devolver **401**, ya la has publicado correctamente; después prueba desde la carpeta con tu sesión. Si devuelve **404 JSON** con `error` al descargar un acta, revisa que el número, `guild_id` y la titularidad del acta coincidan (no es un fallo de publicación).

## Error de imágenes Discord — HTTP 404

`cdn.discordapp.com/ephemeral-attachments/...` es un enlace de adjunto temporal con fecha de expiración. **No es posible reconstruir ese PNG caducado desde la web.** La nueva Carpeta evita usar enlaces efímeros para las imágenes personalizadas y presenta una alternativa visual. Para mostrar la fotografía real del cantante o avatar ficticio, guarda el archivo en una ubicación estable (por ejemplo Supabase Storage público con permisos apropiados) y guarda la nueva URL en la ficha.

## Notas de seguridad y pruebas

- `SUPABASE_SERVICE_KEY` y `JWT_SECRET` solo pueden usarse en funciones del servidor de Vercel, nunca con prefijo `VITE_`.
- El motor PDF vuelve a validar la cookie JWT y pertenencia del acta al ciudadano. El navegador no elige el propietario de un Pokémon.
- Se ha comprobado la **sintaxis** de `Carpeta.tsx`, `citizenRoutes.js`, `server.js` y los scripts Python; no hay conexión disponible a tu Supabase real, no se ha ejecutado el build completo de tu repositorio ni el despliegue en Vercel.
- Para verificar completamente el 404 de los certificados, necesito ver tu archivo actual `vercel.json` (o la configuración de routing de Vercel si no existe).
