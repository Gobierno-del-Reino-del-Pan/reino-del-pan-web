# Estado Paniense · Carpeta 4.1 — encabezados y XP del bot

## Cambia solamente estos dos archivos

1. `src/pages/Carpeta.tsx` → reemplázalo por el nuevo `Carpeta.tsx`.
2. `citizenRoutes.js` → reemplázalo por el nuevo `citizenRoutes.js`, en la ubicación actual de tu proyecto (la misma que importa `server.js`).
3. Haz commit y despliega de nuevo en Vercel. Usa recarga forzada del navegador si ves código anterior.

**NO modifiques `server.js`, `vercel.json`, el Registro Civil, Rotomi ni Supabase.** Esta versión no necesita migraciones SQL.

## Qué corrige

- Rótulos como «IDENTIFICACIÓN CIUDADANA», «VÍNCULOS FAMILIARES», «CAJAS ROTOMI», etc., quedan **separados de los títulos grandes** por un espacio vertical explícito. Los títulos de panel son nodos con `role="heading"` (accesibles) para aislarlos de los estilos `h2` globales del proyecto.
- El título de portada también está aislado de las reglas generales del elemento HTML `h1`.
- Diseño adaptado para escritorio, tableta y móvil; botones y rutas del proyecto existentes intactos.
- La barra XP utiliza el **mismo algoritmo exacto** que el `AEPTCog` de Discord que facilitaste:

```python
xp_needed_for_next(level) = 5 * (level ** 2) + 50 * level + 100
total_xp_for_level(level) = (5 * level * (level - 1) * (2 * level - 1)) // 6 + 25 * level * (level - 1) + 100 * level
progress_xp(total_xp, level) = total_xp - total_xp_for_level(level)
```

El backend toma `total_xp` de `user_levels` (tabla del bot), **recalcula** el nivel y determina la XP transcurrida dentro de él, exactamente como el bot. Ya no usa variables de entorno ni fórmula aproximada.

### Verificación del ejemplo

Para 113.809 XP acumuladas, el bot calcula:

| Métrica | Valor |
|---|---:|
| Nivel | 36 |
| Inicio del nivel 36 | 109.650 XP |
| Progreso del nivel | 4.159 XP |
| Objetivo nivel 37 | 8.380 XP |
| XP que faltan | 4.221 XP |
| Porcentaje redondeado | 50 % |

Si el perfil cambia de XP mientras la página está abierta, vuelve a cargar para recibir la lectura actual del servidor.

## Estado de las pruebas

- Comprobada la sintaxis de `citizenRoutes.js` y TSX.
- Verificado el espacio entre los rótulos y encabezados y que no hay desbordamiento horizontal en pruebas visuales locales a 390, 800, 1024 y 1440 px.
- No se han podido probar peticiones reales a tu Vercel/Supabase: deben comprobarse tras el despliegue.
