-- Supabase SQL Editor. Guarda fotos elegidas desde el dispositivo en Storage.
-- Solo el backend del Estado Paniense escribe usando SUPABASE_SERVICE_KEY.
-- Público significa que el enlace de la foto se puede mostrar en carpetas públicas.
-- No añadas políticas INSERT para anon ni authenticated.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('carpeta-cantantes', 'carpeta-cantantes', true, 2097152,
        array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update
set public = true,
    file_size_limit = excluded.file_size_limit,
    allowed_mime_types = excluded.allowed_mime_types;
