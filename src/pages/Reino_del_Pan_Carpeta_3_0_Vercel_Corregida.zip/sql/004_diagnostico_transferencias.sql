-- SOLO DIAGNÓSTICO. No cambia nada. Ejecútalo en Supabase > SQL Editor.
-- Si NO hay fila para transferir_captura_paniense, instala
-- 001_rotomi_transferencias.sql (tras revisar el esquema de capturas).
select p.proname, pg_get_function_identity_arguments(p.oid) as argumentos,
       has_function_privilege('service_role', p.oid, 'EXECUTE') as ejecutable_por_servidor
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public' and p.proname like 'transferir_captura_%';

select column_name, data_type, is_nullable
from information_schema.columns
where table_schema = 'public' and table_name = 'capturas'
  and column_name in ('id','discord_id','pokemon_id')
order by ordinal_position;
