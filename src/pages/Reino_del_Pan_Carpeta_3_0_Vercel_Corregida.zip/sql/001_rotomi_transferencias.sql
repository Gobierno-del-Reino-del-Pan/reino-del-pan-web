-- Ejecuta en el editor SQL de Supabase DESPUÉS de hacer copia de seguridad.
-- Reutiliza public.capturas (cog Pokémon); NO crea una segunda colección.
-- Requiere public.capturas.id (entero/int8) y .discord_id (texto/varchar).

create table if not exists public.rotomi_transferencias (
  id bigint generated always as identity primary key,
  captura_id bigint not null,
  pokemon_id integer,
  origen_discord_id text not null,
  destino_discord_id text not null,
  created_at timestamptz not null default now(),
  constraint transfer_personas_distintas check (origen_discord_id <> destino_discord_id)
);

alter table public.rotomi_transferencias enable row level security;
revoke all on public.rotomi_transferencias from anon, authenticated;

-- Una transferencia y su asiento de auditoría ocurren en UNA SOLA transacción.
-- Solo el backend con service_role puede ejecutarla. El servidor debe validar
-- la identidad real del emisor y no aceptar p_sender_id desde el cliente.
create or replace function public.transferir_captura_paniense(
  p_capture_id bigint, p_sender_id text, p_recipient_id text
) returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_pokemon_id integer;
  v_dpi text;
begin
  if p_sender_id is null or p_recipient_id is null or p_sender_id = p_recipient_id
     or p_sender_id !~ '^\d{15,22}$' or p_recipient_id !~ '^\d{15,22}$' then
    raise exception 'Destinatario no válido';
  end if;

  select v.dpi into v_dpi from public.verificados v
  join public.dpis d on d.dpi_number = v.dpi
  where v.discord_id = p_recipient_id limit 1;
  if v_dpi is null then
    raise exception 'El destinatario necesita un DPI verificado';
  end if;

  if not exists (select 1 from public.usuarios u where u.discord_id = p_recipient_id) then
    raise exception 'El destinatario aún no tiene perfil en el Reino';
  end if;

  -- El UPDATE adquiere el bloqueo de fila. Si un proceso transfiere la
  -- captura primero, otra petición ya no encuentra un dueño coincidente.
  update public.capturas
     set discord_id = p_recipient_id
   where id = p_capture_id and discord_id = p_sender_id
  returning pokemon_id into v_pokemon_id;

  if not found then
    raise exception 'La captura ya no está disponible en tu PC';
  end if;

  insert into public.rotomi_transferencias
    (captura_id, pokemon_id, origen_discord_id, destino_discord_id)
  values (p_capture_id, v_pokemon_id, p_sender_id, p_recipient_id);
end;
$$;

revoke all on function public.transferir_captura_paniense(bigint,text,text)
  from public, anon, authenticated;
grant execute on function public.transferir_captura_paniense(bigint,text,text)
  to service_role;

-- Comprobar que ninguna política previa permite actualizar el propietario de
-- capturas directamente desde el navegador. Nunca exponer SERVICE_ROLE_KEY.
