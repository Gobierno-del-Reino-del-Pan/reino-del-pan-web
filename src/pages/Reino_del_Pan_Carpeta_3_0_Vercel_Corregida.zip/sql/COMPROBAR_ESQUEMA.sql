-- Ejecutar primero en SQL Editor de Supabase. Solo lectura.
select column_name, data_type, is_nullable, column_default
from information_schema.columns
where table_schema='public' and table_name='capturas'
order by ordinal_position;

-- Confirma que public.capturas tiene un id único para permitir transferencias.
-- NO agregues columnas a ciegas si ya tiene otra clave primaria.
