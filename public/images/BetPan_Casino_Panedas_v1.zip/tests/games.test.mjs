import test from 'node:test';import assert from 'node:assert/strict';
import {play,score,freshBlackjack,advanceBlackjack,publicBlackjack} from '../server/games.mjs';
for(const [game,choice,max] of [['coin','cara',2],['dice',4,6],['roulette','rojo',2],['roulette','n:36',36],['slots',null,25],['bingo',null,30],['krule',null,8]]){
 test(`${game}: outcomes only server-side, maximum payout`,()=>{for(let i=0;i<300;i++){const v=play(game,100,choice);assert.ok(v.payout>=0&&v.payout<=100*max);assert.ok(v.result);}});
}
test('blackjack: card values',()=>{assert.equal(score([{rank:'A',value:11},{rank:'K',value:10}]),21);assert.equal(score([{rank:'A',value:11},{rank:'K',value:10},{rank:'9',value:9}]),20);});
test('blackjack: dealer secret hidden from client',()=>{const round={status:'active',state:freshBlackjack()};const v=publicBlackjack(round);assert.equal(v.state.dealer[1].rank,'?');assert.ok(!('deck' in v.state));});
test('blackjack: finish always terminal',()=>{const state=freshBlackjack();const a=advanceBlackjack(state,'stand',100);assert.ok(a.finish);assert.equal(a.state.turn,'finished');assert.ok([0,100,200,250].includes(a.payout));});
