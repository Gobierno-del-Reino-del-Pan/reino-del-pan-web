# BetPan v1.0 — Casino de las Panedas (Estado Paniense)

> **SIMULACIÓN EXCLUSIVA**: moneda ficticia PND (Panedas) sin valor monetario. NO se acepta dinero real ni criptomonedas; NO se pueden comprar, vender, retirar o convertir las Panedas en € u otros activos; NO se ofrecen premios económicos ni bienes canjeables. Nunca añadir pasarelas de pago, recargas ni conversión.

## Qué contiene

- `src/pages/BetPan.tsx` + `BetPan.css`: web completa responsive (usan el Header actual, marca `/images/bet.png`).
- `server/games.mjs`: lógica criptográficamente aleatoria (servidor) de ruleta europea, slots, cara/cruz, dados, bingo rápido individual, Krule, Blackjack interactivo (pedir/plantarse).
- `server/router.mjs`: API Express `/api/betpan` con sesión de Discord, límites, partidas idempotentes y saldo.
- `server/sports.mjs`: importación automática de próximos partidos y resultados de LaLiga desde football-data.org, liquidación 1X2 sin configuración de encuentros individuales.
- `sql/001_betpan.sql`: tablas, libro mayor y funciones transaccionales sobre `public.users_economy.cash`.
- `scripts/sync-sports.mjs`: tarea recurrente externa o cron de Vercel.
- `tests/games.test.mjs`: pruebas de mecánica de juegos.

## Integración requerida (el ZIP no puede acceder a tu servidor real)

1. Haz backup de `users_economy` y revisa el SQL antes de ejecutarlo en Supabase SQL Editor. **No borra la tabla anterior**. Las funciones usan **SECURITY INVOKER** y solo deberían ejecutarse desde el backend con `service_role`. Comprueba también las políticas RLS existentes de `users_economy` (nadie debe poder actualizar `cash`/`bank` directamente desde cliente).
2. Copia los archivos y ejecuta `npm install express @supabase/supabase-js dotenv` en el proyecto que contiene `server.js`; React y Wouter ya estarán instalados en la web, si no `npm install wouter`. Las importaciones de `server/router.mjs` son ESM.
3. Declara `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `FOOTBALL_DATA_TOKEN`, `CRON_SECRET` **solo en el backend**, copiando `.env.example`. Nunca uses prefijos `VITE_` para claves secretas. Asegura un secreto largo con `openssl rand -hex 32`.
4. En `server.js`, **después de la sesión real de Discord** y `express.json`, pero **antes del fallback SPA**, monta:

```js
import {createBetPanRouter} from './server/router.mjs';
app.use('/api/betpan', createBetPanRouter({
  getUserId: req => {
    // ADAPTAR a la sesión REAL del backend; NO confiar en IDs enviados por el navegador.
    const id = req.user?.id ?? req.session?.discordUser?.id ?? req.session?.user?.id;
    return typeof id === 'string' && /^\d{15,22}$/.test(id) ? id : null;
  }
}));
```

5. En el router Wouter añade la ruta **`/lpb`** tal como está el `Header` que pasaste:

```tsx
import BetPan from './pages/BetPan';
<Route path="/lpb" component={BetPan}/>
```

6. El logo ya referenciado en el TSX es `public/images/bet.png`. Si está en otro directorio, cópialo allí.
7. Tu Header actual ya tiene el link a `/lpb` para BetPan; no hace falta modificarlo.
8. Despliega e inicia sincronización deportiva: `npm run sports:sync` cada día o GET `https://TU_DOMINIO/api/betpan/cron/sports` con `Authorization: Bearer <CRON_SECRET>`. Opcional `vercel.json` (fragmento a **integrar**, NO sustituir tu config):

```json
{"crons":[{"path":"/api/betpan/cron/sports","schedule":"15 5 * * *"}]}
```

> En Vercel Hobby el cron puede ejecutarse una sola vez al día. Por tanto, la liquidación **no será instantánea**: dependerá de la siguiente ejecución y de que el proveedor reporte FINISHED. En planes con cron más frecuente o servidor permanente puede ejecutarse cada 15–60 min. Las cuotas 1X2 internas (2,70 / 3,20 / 2,70) son ficticias, no precios reales del mercado.

## Seguridad y economía

- Solo se usa `cash` de `public.users_economy`, **nunca** se descuenta `bank`. El ledger registra apuesta y premio, y `total_earned`/`total_spent` se actualizan junto a cada saldo.
- No hay endpoints para acreditar saldo gratis, comprar Panedas o convertirlas a dinero real.
- Mínimo 10 PND, máximo 10.000 por jugada. 25 acciones/min por sesión a nivel de proceso. La consulta de balances y sesiones son server-side. Si hay múltiples instancias, implementa un rate limiter persistente. Se comprueba el encabezado `Origin` en las solicitudes POST; configura `BETPAN_ORIGIN` con la URL pública de la web y mantén las cookies de sesión con `SameSite=Lax` o `Strict`.
- `requestId` UUID evita debitar dos veces jugadas repetidas; el estado de Blackjack se guarda en BD sin revelar baraja/segunda carta a los clientes.
- Eventos y resultados provienen de una API externa. Si no hay `FOOTBALL_DATA_TOKEN`, la sección deportes informa de ello y no crea encuentros falsos.
- Nunca llamar Supabase con `service_role` desde TSX/JS del navegador. Nunca confiar en `userId` enviado en el body ni `?id=`.

## Definiciones de reglas

**Modo Krule**: modo original diseñado como propuesta hasta recibir reglas oficiales: se tiran 3 dados, trío x8, pareja x2, suma de 14 o más x1,5, en otro caso x0. **Bingo** es individual y rápido, no una sala multijugador en tiempo real. **Blackjack** permite pedir/plantarse, sin dividir/doblar ni seguros en esta versión.

## Nota sobre el archivo que compartiste

El TXT adjunto es el componente `Header` (incluye el enlace a BetPan), NO contiene el código anterior del banco. El ZIP por tanto incluye un módulo que se integra en tu backend existente; para conectarlo a tu sesión Discord concreta, hay que comprobar el middleware real de `server.js`. Sin `SUPABASE_SERVICE_ROLE_KEY`, PostgreSQL desplegado y el backend integrador, no se puede declarar en producción funcional por el mero hecho de copiar los archivos.

## Tests

```sh
npm install
npm test
```
