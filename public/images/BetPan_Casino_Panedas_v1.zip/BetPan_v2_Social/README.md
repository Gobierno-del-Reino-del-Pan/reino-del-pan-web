# BetPan 2.0 — Edición social + premios deportivos

> Solo Panedas ficticias (PND). No son dinero real, ni se compran ni se convierten en euros.

## Instalación: exactamente en este orden

1. **Haz copia de seguridad** del proyecto y revisa la migración `sql/004_betpan_social_deportes.sql`.
2. Abre **Supabase → SQL Editor** del proyecto **que ya usa BetPan** y ejecuta el contenido completo de `sql/004_betpan_social_deportes.sql`, **una sola vez**. Es compatible con `001_betpan.sql` y `002_wallet_bank.sql`. No borra partidas ni apuestas. Si la SQL da error, no despliegues el nuevo código hasta resolverlo. Las columnas para escudos y pagos deben existir antes de desplegar.
3. En la **raíz del repositorio**, junto a `server.js`, sustituye **solo** `BetPan.mjs` por el archivo nuevo.
4. Sustituye el TSX de la página de BetPan por `BetPan.tsx` (en tu estructura anterior, `src/pages/LaboralBank/BetPan.tsx`; usa la ubicación real de tu página). **Incluye todo el CSS**; no hay que añadir CSS aparte.
5. **No tienes que tocar `server.js`** si sigue siendo el que ya integramos: ya contiene el `import` y el montaje `/api/betpan`. Incluimos en `referencia/server.js` una copia de ese archivo, **sin un solo byte modificado**, solo para comparación; no sobrescribas un `server.js` con trabajo más reciente.
6. Realiza commit en GitHub y comprueba en Vercel que la nueva compilación está **Ready**. Las variables `FOOTBALL_DATA_TOKEN` y `CRON_SECRET` **siguen exclusivamente en Vercel**; no hay nuevas variables de entorno.
7. Comprueba `https://TU-DOMINIO/api/betpan/health`. Para cargar **los escudos y marcadores** inmediatamente, ejecuta una sincronización manual desde PowerShell (sustituye valores sin publicarlos):
   ```powershell
   curl.exe -H "Authorization: Bearer TU_CRON_SECRET" "https://TU-DOMINIO/api/betpan/cron/sports"
   ```
8. Entra con distintas **cuentas reales de Discord**: crea una mesa de ruleta con 2 usuarios, y después prueba el bingo con **5 usuarios**. Comprueba que el premio/reembolso aparece en la cartera de origen (efectivo o banco).

## Qué incluye

- **Casino social**: mesas para ruleta, slots, cara/cruz, dados, Modo Krule y blackjack automático; **30 segundos** para apostar y **mínimo 2 usuarios**. Todos comparten mesa y resultado. Se muestran nombres y avatares de Discord.
- **Blackjack individual intacto** con «Pedir carta» y «Plantarse». El **blackjack en mesa** es un modo automático separado: cada persona selecciona el umbral objetivo (16–20) antes de cerrar la inscripción.
- **Bingo multijugador real**: mínimo 5 participantes, cartones únicos 5×5 con casilla libre, bolas extraídas progresivamente, primer premio de línea (20 % del bote) y primer premio de bingo (80 %). Apuestas reembolsadas si no hay 5 personas.
- **Sala compartida y cronómetro**: las decisiones y premios se hacen en backend PostgreSQL mediante operaciones atómicas. La interfaz consulta el estado aprox. cada 1,7 segundos. En Vercel serverless **no hay un proceso residente**: la sala avanza cuando algún cliente consulta el estado o en la tarea cron diaria; si todos abandonan una mesa antes de terminar, el cierre podría retrasarse.
- **Deportes**: escudos de Football-Data, resultados reales 1–X–2, próxima jornada, partidos en vivo y marcadores finales.
- **«Mis apuestas»**: últimas 50, filtros pendiente/premiada/perdida/reembolsada, partido y marcador, pronóstico, cuota, importe, cartera, premio fijo, parte de perdedores y total abonado.
- **Premio deportivo adicional**: cada ganador recibe `floor(apuesta × cuota)` **más** su parte del fondo de las apuestas falladas. El fondo se distribuye **proporcionalmente** al importe de cada acierto, sin crear dinero adicional dentro del propio reparto (el premio fijo sí lo financia el juego). Se reparte cada PND del fondo; los restos por redondeo se asignan de manera determinista. Si no hay ganadores, el fondo no se paga a nadie. Si se cancela el encuentro, se devuelven todas las apuestas.
- **Pagos una sola vez**: al liquidarse una ronda o partido se cambia su estado, se abona a la cartera original y se genera una clave única de operación en el libro de movimientos. Ejecutar el cron otra vez no debería repetir el abono.

### Ejemplo de premios (LaLiga)

Ganan las apuestas a **Local** de Ana (100 PND) y Luis (200 PND), ambas con cuota **×2,70**. Marta apuesta **300 PND** a Visitante y falla.

| Persona | Premio por cuota | Parte de los 300 PND perdidos | Premio bruto total |
|---|---:|---:|---:|
| Ana | 270 | 100 | **370 PND** |
| Luis | 540 | 200 | **740 PND** |
| Marta | 0 | 0 | **0 PND** |

Los 300 PND perdidos se reparten en proporción **100:200**, no se abonan 300 PND completos a cada ganador. Las apuestas ya liquidadas antes de esta versión **no se recalculan retroactivamente**; sus premios antiguos figuran como parte fija en el historial.

## Verificaciones realizadas / pendientes

**Comprobadas localmente:** `node --check BetPan.mjs`; compilación sintáctica TSX con TypeScript; 5 pruebas automáticas sobre el azar compartido, cartones y premios de bingo (todas superadas); `server.js` comprobado byte a byte frente a la integración anterior (SHA-256 igual).

**Pendiente de comprobar en tu infraestructura:** ejecutar la migración contra tu base PostgreSQL y realizar una prueba de extremo a extremo en Vercel con 5 cuentas Discord y un partido finalizado. No se ha ejecutado esta migración ni publicado nuevos archivos por ti.

## Seguridad que conviene revisar

Antes de abrirlo a todos, revisa las políticas RLS de `users_economy`: en la revisión anterior se detectó una política `ALL` excesivamente permisiva. **No la cambiamos automáticamente**, porque podría afectar a otros bots y al banco. Los nuevos datos de salas se protegen con RLS y RPC reservadas a `service_role`. Nunca pongas `SUPABASE_SERVICE_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `CRON_SECRET` ni `FOOTBALL_DATA_TOKEN` en el TSX ni en GitHub.

## Archivos relevantes

- `BetPan.tsx`: única página React, con CSS incluido.
- `BetPan.mjs`: todos los endpoints y juegos backend en un único JavaScript.
- `sql/004_betpan_social_deportes.sql`: migración que hace reales las salas y el reparto deportivo.
- `tests/social.test.cjs`: pruebas repetibles (`node --test tests/social.test.cjs`).
- `referencia/server.js`: el anterior `server.js`, idéntico al que ya integramos, para comparar.
