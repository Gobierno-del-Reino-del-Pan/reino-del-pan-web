const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const {randomInt,timingSafeEqual}=require('node:crypto');
const s=fs.readFileSync(require('node:path').join(__dirname,'..','BetPan.mjs'),'utf8')
 .replace(/^import .*;\s*$/gm,'').replace(/\bexport (async )?(function|const)\b/g,(_,async,kind)=>`${async||''}${kind}`);
const get=new Function('randomInt','timingSafeEqual',s+'\nreturn {makeBingoTicket,createRoomResult,play,score};');
const {makeBingoTicket,createRoomResult,play}=get(randomInt,timingSafeEqual);
test('Cartón de 5x5, números sin duplicar por columnas y centro libre',()=>{
 for(let j=0;j<100;j++){
 const a=makeBingoTicket();assert.equal(a.length,25);assert.equal(a[12],0);
 assert.equal(new Set(a.filter(Boolean)).size,24);
 for(let i=0;i<25;i++){if(i===12)continue;
   const col=i%5;assert.ok(a[i]>col*15&&a[i]<=(col+1)*15);
 }
 }
});
test('Bingo de 5 jugadores: todo el bote asignado sin duplicación',()=>{
 for(let q=0;q<50;q++){
 const players=Array.from({length:5},(_,i)=>({id:'player-'+i,wager:100*(i+1),ticket:makeBingoTicket()}));
 const r=createRoomResult('bingo',players);assert.equal(r.awards.length,5);
 assert.equal(r.awards.reduce((t,p)=>t+p.payout,0),1500);
 assert.ok(r.outcome.drawn.length>=1&&r.outcome.drawn.length<=75);
 assert.equal(new Set(r.outcome.drawn).size,r.outcome.drawn.length);
 assert.ok(r.duration<=120000);
 }
});
test('Multijugador usa un solo resultado de ruleta y respeta plenos',()=>{
 const players=[{id:'red',wager:100,choice:'rojo'},{id:'black',wager:100,choice:'negro'},{id:'zero',wager:100,choice:'n:0'}];
 for(let i=0;i<120;i++){
 const r=createRoomResult('roulette',players);const n=r.outcome.roll;
 const payouts=r.awards.map(x=>x.payout);assert.equal(payouts.filter(x=>x>0).length,1);
 if(n===0)assert.deepEqual(payouts,[0,0,3600]);
 }
});
test('Multijugador mismo dado/moneda y RNG de tragaperras',()=>{
 const players=[{id:'one',wager:100,choice:'1'},{id:'two',wager:100,choice:'2'}];
 for(const game of ['dice','coin','slots','krule','blackjack']){
  const choices=game==='coin'?['cara','cruz']:game==='blackjack'?['17','19']:['1','2'];
  const r=createRoomResult(game,players.map((p,i)=>({...p,choice:choices[i]})));
  assert.equal(r.awards.length,2);assert.ok(r.awards.every(a=>a.payout>=0));
 }
});
test('Todos los pagos individuales usan números enteros',()=>{
 for(const game of ['roulette','coin','dice','krule','slots','bingo']){
  const choices={roulette:'par',coin:'cara',dice:'3'};
  for(let i=0;i<20;i++)assert.ok(Number.isInteger(play(game,123,choices[game]??'').payout));
 }
});
