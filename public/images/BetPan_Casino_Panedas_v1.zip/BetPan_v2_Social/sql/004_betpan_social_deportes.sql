-- BETPAN v2 · Apuestas sociales y resultados deportivos · Panedas ficticias.
-- Aplicar DESPUÉS de 001_betpan.sql y 002_wallet_bank.sql.
-- Mantiene las partidas/apuestas anteriores. No permite acceso directo anónimo a tablas/RPC.
BEGIN;

ALTER TABLE public.betpan_sports_events ADD COLUMN IF NOT EXISTS home_crest text;
ALTER TABLE public.betpan_sports_events ADD COLUMN IF NOT EXISTS away_crest text;
ALTER TABLE public.betpan_sports_events ADD COLUMN IF NOT EXISTS matchday integer;
ALTER TABLE public.betpan_sports_bets ADD COLUMN IF NOT EXISTS base_payout bigint NOT NULL DEFAULT 0;
ALTER TABLE public.betpan_sports_bets ADD COLUMN IF NOT EXISTS pool_bonus bigint NOT NULL DEFAULT 0;

-- Liquidación atómica e idempotente; un único cobro por apuesta.
-- Los ganadores cobran su cuota guardada más su parte de las apuestas perdidas.
-- El fondo de perdedores se reparte proporcionalmente al importe apostado por los ganadores.
-- Si nadie acierta, nadie recibe ese fondo; si el partido se cancela, se devuelve cada apuesta.
CREATE OR REPLACE FUNCTION public.betpan_finalize_event(p_event_id text)
RETURNS jsonb LANGUAGE plpgsql SECURITY INVOKER SET search_path=public AS $$
DECLARE
 e public.betpan_sports_events;
 b public.betpan_sports_bets;
 v_loss_pool bigint:=0;
 v_winner_stakes bigint:=0;
 v_remainder bigint:=0;
 v_floor_total bigint:=0;
 v_floor bigint;
 v_bonus bigint;
 v_base bigint;
 v_amount bigint;
 v_balance bigint;
 v_count integer:=0;
 v_source text;
BEGIN
 SELECT * INTO e FROM public.betpan_sports_events WHERE id=p_event_id FOR UPDATE;
 IF NOT FOUND OR e.status NOT IN ('finished','cancelled')
 THEN RETURN jsonb_build_object('settled',0,'skipped',true); END IF;
 IF e.status='finished' AND (e.winner IS NULL OR e.home_score IS NULL OR e.away_score IS NULL)
 THEN RAISE EXCEPTION 'Falta resultado final'; END IF;

 -- Congelamos las apuestas pendientes en el mismo bloqueo transaccional del partido.
 IF e.status='finished' THEN
   SELECT COALESCE(SUM(stake) FILTER (WHERE pick<>e.winner),0),
          COALESCE(SUM(stake) FILTER (WHERE pick=e.winner),0)
   INTO v_loss_pool,v_winner_stakes
   FROM public.betpan_sports_bets WHERE event_id=p_event_id AND status='pending';
   IF v_winner_stakes>0 THEN
     SELECT COALESCE(SUM(FLOOR(v_loss_pool::numeric * stake / v_winner_stakes)::bigint),0)
       INTO v_floor_total
       FROM public.betpan_sports_bets
       WHERE event_id=p_event_id AND status='pending' AND pick=e.winner;
     v_remainder:=v_loss_pool-v_floor_total;
   END IF;
 END IF;

 FOR b IN SELECT * FROM public.betpan_sports_bets
          WHERE event_id=p_event_id AND status='pending'
          ORDER BY id FOR UPDATE
 LOOP
   v_source:=COALESCE(b.wallet_source,'cash');
   v_base:=0;
   v_bonus:=0;
   IF e.status='cancelled' THEN
     v_amount:=b.stake;
   ELSIF b.pick=e.winner THEN
     v_base:=b.possible_payout;
     IF v_winner_stakes>0 THEN
       v_floor:=FLOOR(v_loss_pool::numeric*b.stake/v_winner_stakes)::bigint;
       v_bonus:=v_floor+CASE WHEN v_remainder>0 THEN 1 ELSE 0 END;
       IF v_remainder>0 THEN v_remainder:=v_remainder-1; END IF;
     END IF;
     v_amount:=v_base+v_bonus;
   ELSE
     v_amount:=0;
   END IF;

   UPDATE public.betpan_sports_bets
   SET status=CASE WHEN e.status='cancelled' THEN 'refunded'
                   WHEN b.pick=e.winner THEN 'won' ELSE 'lost' END,
       payout=v_amount,base_payout=v_base,pool_bonus=v_bonus,resolved_at=now()
   WHERE id=b.id;
   IF v_amount>0 THEN
     UPDATE public.users_economy
     SET cash=CASE WHEN v_source='cash' THEN COALESCE(cash,0)+v_amount ELSE cash END,
         bank=CASE WHEN v_source='bank' THEN COALESCE(bank,0)+v_amount ELSE bank END,
         total_earned=COALESCE(total_earned,0)+CASE WHEN e.status='cancelled' THEN 0 ELSE v_amount END,
         total_spent=COALESCE(total_spent,0)-CASE WHEN e.status='cancelled' THEN b.stake ELSE 0 END,
         updated_at=now()
     WHERE id=b.user_id
     RETURNING (CASE WHEN v_source='cash' THEN COALESCE(cash,0) ELSE COALESCE(bank,0) END)
     INTO v_balance;
     IF NOT FOUND THEN RAISE EXCEPTION 'Cuenta económica inexistente'; END IF;
     INSERT INTO public.betpan_ledger(user_id,operation_key,delta,balance_after,reason,wallet_source)
     VALUES(b.user_id,b.id::text||':settlement',v_amount,v_balance,
        CASE WHEN e.status='cancelled' THEN 'betpan:deportes:reembolso'
             ELSE 'betpan:deportes:premio_cuota_y_bote' END,v_source);
   END IF;
   v_count:=v_count+1;
 END LOOP;
 RETURN jsonb_build_object('settled',v_count,'event',p_event_id,'loser_pool',v_loss_pool,
   'winning_stakes',v_winner_stakes);
END; $$;

-- La nueva regla se aplica a apuestas pendientes. Las anteriores ya pagadas mantienen
-- su liquidación original, que registramos como premio fijo para el panel histórico.
UPDATE public.betpan_sports_bets SET base_payout=payout
WHERE status='won' AND payout>0 AND base_payout=0 AND pool_bonus=0;

-- Salas sociales. Los datos privados de apuestas y sorteos solo se consultan por el servidor.
CREATE TABLE IF NOT EXISTS public.betpan_rooms (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 game text NOT NULL CHECK (game IN ('roulette','slots','coin','dice','krule','bingo','blackjack')),
 status text NOT NULL DEFAULT 'joining' CHECK (status IN ('joining','drawing','settled','cancelled')),
 created_at timestamptz NOT NULL DEFAULT now(),
 starts_at timestamptz NOT NULL DEFAULT (now()+INTERVAL '30 seconds'),
 draw_ends_at timestamptz,
 finished_at timestamptz,
 result jsonb NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS betpan_rooms_live_idx ON public.betpan_rooms(game,status,starts_at);
CREATE TABLE IF NOT EXISTS public.betpan_room_players (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 request_id uuid NOT NULL UNIQUE,
 room_id uuid NOT NULL REFERENCES public.betpan_rooms(id) ON DELETE CASCADE,
 user_id text NOT NULL REFERENCES public.users_economy(id),
 wager bigint NOT NULL CHECK (wager BETWEEN 10 AND 10000),
 choice text NOT NULL DEFAULT '',
 wallet_source text NOT NULL CHECK (wallet_source IN ('cash','bank')),
 ticket jsonb NOT NULL DEFAULT '[]'::jsonb,
 payout bigint NOT NULL DEFAULT 0 CHECK (payout>=0),
 status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','won','lost','refunded')),
 joined_at timestamptz NOT NULL DEFAULT now(),
 CONSTRAINT betpan_room_one_player UNIQUE (room_id,user_id)
);
CREATE INDEX IF NOT EXISTS betpan_room_players_user_idx ON public.betpan_room_players(user_id,joined_at DESC);
CREATE INDEX IF NOT EXISTS betpan_room_players_room_idx ON public.betpan_room_players(room_id);
ALTER TABLE public.betpan_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.betpan_room_players ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.betpan_rooms,public.betpan_room_players FROM anon,authenticated;
GRANT SELECT,INSERT,UPDATE,DELETE ON public.betpan_rooms,public.betpan_room_players TO service_role;

-- Une a una sala (o abre otra) y descuenta la apuesta en UNA transacción.
CREATE OR REPLACE FUNCTION public.betpan_room_join(
 p_uid text,p_game text,p_wager bigint,p_choice text,p_source text,p_request_id uuid,p_ticket jsonb
) RETURNS public.betpan_room_players LANGUAGE plpgsql SECURITY INVOKER SET search_path=public AS $$
DECLARE r public.betpan_rooms; p public.betpan_room_players; v_balance bigint;
BEGIN
 IF p_game NOT IN ('roulette','slots','coin','dice','krule','bingo','blackjack')
    OR p_wager NOT BETWEEN 10 AND 10000 OR p_request_id IS NULL OR p_uid IS NULL
    OR p_source NOT IN ('cash','bank') OR length(COALESCE(p_choice,''))>30
 THEN RAISE EXCEPTION 'Parámetros de sala inválidos'; END IF;
 -- Una cola por juego: bloqueo para evitar crear dos salas abiertas en paralelo.
 PERFORM pg_advisory_xact_lock(hashtext('betpan:room:'||p_game));
 SELECT * INTO p FROM public.betpan_room_players WHERE request_id=p_request_id;
 IF FOUND THEN
   IF p.user_id<>p_uid OR p.wager<>p_wager OR p.wallet_source<>p_source
   THEN RAISE EXCEPTION 'Idempotencia incompatible'; END IF;
   RETURN p;
 END IF;
 SELECT r0.* INTO r FROM public.betpan_rooms r0
 WHERE r0.game=p_game AND r0.status='joining' AND r0.starts_at>now()
 ORDER BY r0.starts_at ASC LIMIT 1 FOR UPDATE;
 IF NOT FOUND THEN
   INSERT INTO public.betpan_rooms(game) VALUES(p_game) RETURNING * INTO r;
 END IF;
 SELECT * INTO p FROM public.betpan_room_players WHERE room_id=r.id AND user_id=p_uid;
 IF FOUND THEN RAISE EXCEPTION 'Ya participas en esta sala'; END IF;
 IF (SELECT COUNT(*) FROM public.betpan_room_players WHERE room_id=r.id)>=40
 THEN RAISE EXCEPTION 'Sala llena (40 jugadores)'; END IF;
 INSERT INTO public.users_economy(id,cash,bank) VALUES(p_uid,0,0) ON CONFLICT(id) DO NOTHING;
 INSERT INTO public.betpan_room_players(request_id,room_id,user_id,wager,choice,wallet_source,ticket)
 VALUES(p_request_id,r.id,p_uid,p_wager,COALESCE(p_choice,''),p_source,
   CASE WHEN p_game='bingo' THEN p_ticket ELSE '[]'::jsonb END) RETURNING * INTO p;
 UPDATE public.users_economy
 SET cash=CASE WHEN p_source='cash' THEN COALESCE(cash,0)-p_wager ELSE cash END,
     bank=CASE WHEN p_source='bank' THEN COALESCE(bank,0)-p_wager ELSE bank END,
     total_spent=COALESCE(total_spent,0)+p_wager,updated_at=now()
 WHERE id=p_uid AND (CASE WHEN p_source='cash' THEN COALESCE(cash,0) ELSE COALESCE(bank,0) END)>=p_wager
 RETURNING CASE WHEN p_source='cash' THEN COALESCE(cash,0) ELSE COALESCE(bank,0) END
 INTO v_balance;
 IF NOT FOUND THEN RAISE EXCEPTION 'Saldo insuficiente'; END IF;
 INSERT INTO public.betpan_ledger(user_id,operation_key,delta,balance_after,reason,wallet_source)
 VALUES(p_uid,p.id::text||':stake',-p_wager,v_balance,'betpan:sala:'||p_game||':apuesta',p_source);
 RETURN p;
END; $$;

-- Congela resultado generado por Node crypto; si no hay jugadores suficientes cancela.
CREATE OR REPLACE FUNCTION public.betpan_room_begin(p_room uuid,p_result jsonb,p_duration_ms integer)
RETURNS public.betpan_rooms LANGUAGE plpgsql SECURITY INVOKER SET search_path=public AS $$
DECLARE r public.betpan_rooms; v_players integer; v_min integer;
BEGIN
 SELECT * INTO r FROM public.betpan_rooms WHERE id=p_room FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Sala inexistente'; END IF;
 IF r.status<>'joining' THEN RETURN r; END IF;
 IF r.starts_at>now() THEN RETURN r; END IF;
 SELECT COUNT(*) INTO v_players FROM public.betpan_room_players WHERE room_id=r.id;
 v_min:=CASE WHEN r.game='bingo' THEN 5 ELSE 2 END;
 IF v_players<v_min THEN
   UPDATE public.betpan_rooms SET status='cancelled',finished_at=now(),
     result=jsonb_build_object('message','Jugadores insuficientes; apuestas reembolsadas')
   WHERE id=r.id RETURNING * INTO r;
   RETURN r;
 END IF;
 IF p_duration_ms IS NULL OR p_duration_ms NOT BETWEEN 1500 AND 120000
    OR p_result IS NULL OR jsonb_typeof(p_result)<>'object'
 THEN RAISE EXCEPTION 'Resultado de sala inválido'; END IF;
 UPDATE public.betpan_rooms
 SET status='drawing',result=p_result,
     draw_ends_at=now()+(p_duration_ms * INTERVAL '1 millisecond')
 WHERE id=r.id RETURNING * INTO r;
 RETURN r;
END; $$;

-- Finaliza y transfiere premios o reembolsos a la cartera original exactamente una vez.
CREATE OR REPLACE FUNCTION public.betpan_room_finalize(p_room uuid)
RETURNS public.betpan_rooms LANGUAGE plpgsql SECURITY INVOKER SET search_path=public AS $$
DECLARE r public.betpan_rooms; p public.betpan_room_players;
 v_result jsonb; v_award jsonb; v_payout bigint; v_balance bigint; v_refund boolean;
 v_n integer; v_entries integer;
BEGIN
 SELECT * INTO r FROM public.betpan_rooms WHERE id=p_room FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Sala inexistente'; END IF;
 IF r.status IN ('settled','cancelled') AND EXISTS (
   SELECT 1 FROM public.betpan_room_players WHERE room_id=r.id AND status='pending'
 ) AND r.status='settled' THEN
   RAISE EXCEPTION 'Estado de sala inconsistente';
 END IF;
 IF r.status NOT IN ('drawing','cancelled') THEN RETURN r; END IF;
 IF r.status='drawing' AND r.draw_ends_at>now() THEN RETURN r; END IF;
 v_refund:=(r.status='cancelled');
 v_result:=r.result;
 IF NOT v_refund THEN
   IF jsonb_typeof(v_result->'awards')<>'array' THEN RAISE EXCEPTION 'Faltan premios'; END IF;
   SELECT COUNT(*) INTO v_n FROM public.betpan_room_players WHERE room_id=r.id;
   SELECT COUNT(*) INTO v_entries FROM jsonb_array_elements(v_result->'awards');
   IF v_n<>v_entries THEN RAISE EXCEPTION 'Cantidad de premios incompatible'; END IF;
 END IF;
 FOR p IN SELECT * FROM public.betpan_room_players WHERE room_id=r.id AND status='pending' ORDER BY id FOR UPDATE LOOP
   IF v_refund THEN v_payout:=p.wager;
   ELSE
     SELECT elem.value INTO v_award FROM jsonb_array_elements(v_result->'awards') AS elem(value)
     WHERE elem.value->>'id'=p.id::text;
     IF NOT FOUND OR (v_award->>'payout') IS NULL THEN RAISE EXCEPTION 'Premio inexistente'; END IF;
     v_payout:=(v_award->>'payout')::bigint;
     IF v_payout<0 OR v_payout>10000000 THEN RAISE EXCEPTION 'Premio fuera de límites'; END IF;
   END IF;
   UPDATE public.betpan_room_players SET payout=v_payout,
     status=CASE WHEN v_refund THEN 'refunded' WHEN v_payout>0 THEN 'won' ELSE 'lost' END
   WHERE id=p.id;
   IF v_payout>0 THEN
     UPDATE public.users_economy
     SET cash=CASE WHEN p.wallet_source='cash' THEN COALESCE(cash,0)+v_payout ELSE cash END,
         bank=CASE WHEN p.wallet_source='bank' THEN COALESCE(bank,0)+v_payout ELSE bank END,
         total_earned=COALESCE(total_earned,0)+CASE WHEN v_refund THEN 0 ELSE v_payout END,
         total_spent=COALESCE(total_spent,0)-CASE WHEN v_refund THEN p.wager ELSE 0 END,
         updated_at=now()
     WHERE id=p.user_id
     RETURNING CASE WHEN p.wallet_source='cash' THEN COALESCE(cash,0) ELSE COALESCE(bank,0) END
     INTO v_balance;
     IF NOT FOUND THEN RAISE EXCEPTION 'Cuenta económica inexistente'; END IF;
     INSERT INTO public.betpan_ledger(user_id,operation_key,delta,balance_after,reason,wallet_source)
     VALUES(p.user_id,p.id::text||':settlement',v_payout,v_balance,
       CASE WHEN v_refund THEN 'betpan:sala:reembolso' ELSE 'betpan:sala:premio' END,
       p.wallet_source);
   END IF;
 END LOOP;
 IF NOT v_refund THEN
   UPDATE public.betpan_rooms SET status='settled',finished_at=now() WHERE id=r.id RETURNING * INTO r;
 END IF;
 RETURN r;
END; $$;

REVOKE ALL ON FUNCTION public.betpan_finalize_event(text) FROM PUBLIC,anon,authenticated;
REVOKE ALL ON FUNCTION public.betpan_room_join(text,text,bigint,text,text,uuid,jsonb) FROM PUBLIC,anon,authenticated;
REVOKE ALL ON FUNCTION public.betpan_room_begin(uuid,jsonb,integer) FROM PUBLIC,anon,authenticated;
REVOKE ALL ON FUNCTION public.betpan_room_finalize(uuid) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.betpan_finalize_event(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.betpan_room_join(text,text,bigint,text,text,uuid,jsonb) TO service_role;
GRANT EXECUTE ON FUNCTION public.betpan_room_begin(uuid,jsonb,integer) TO service_role;
GRANT EXECUTE ON FUNCTION public.betpan_room_finalize(uuid) TO service_role;
COMMIT;
