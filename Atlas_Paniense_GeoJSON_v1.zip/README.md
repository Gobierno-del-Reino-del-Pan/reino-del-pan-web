# ESTADO PANIENSE — ATLAS TERRITORIAL v2.2

**Actualización sobre la v2.1.** Mantiene React + TypeScript + Leaflet + CARTO opcional, sin tocar Supabase. El GeoJSON es información espacial efectiva (`FeatureCollection`), no polígonos inventados.

## Cambios verificables

- **Andorra**: las siete parroquias históricas procedentes de geoBoundaries AND ADM1 (2007) se disuelven (`shapely.ops.unary_union`) en **tres geometrías regionales**. No se ven fronteras parroquiales interiores por defecto. Un nuevo interruptor permite activarlas como líneas finas.
  - **Pimbo** = Ordino + La Massana + Sant Julià de Lòria → capital **Pimbolandia**, en Ordino. La región es `MultiPolygon` por tener sectores desconectados.
  - **Baguette** = Andorra la Vella + Escaldes-Engordany → capital **Pantopía** (Estado Paniense y Baguette).
  - **Croissant** = Encamp + Canillo → capital **Vila Croissant**, en Meritxell.
- **Pretzel**: se unen las diez comunas de la costa vasca francesa ya incluidas en v2.1; su capital sigue siendo **Pretzelópolis**, en Bayona. Selección de comunas pendiente de ratificación.
- **Sin Glúten**: se incluye un **polígono municipal generalizado real** de Torroella de Montgrí (Cataluña) como **propuesta de sector continental**. Sus coordenadas provienen del TopoJSON `cat-municipis.json` de `sirisacademic/catalonia-cartography`, identificador 171997. **Este polígono no cubre las islas Medas**. ChinPan está en Meda Gran y se ha fijado usando una referencia de localización real de OSM, way 4791233. Para incorporar las costas de las islas con coordenadas reales, se incluye el importador de Overpass descrito abajo.
- **Pan Plano / Arepa**: se ha retirado del mapa político el polígono histórico provincial simplificado de Tierra del Fuego que **no contenía Ushuaia**. Se conserva, sin relleno y solo si se activa el interruptor de contexto, como referencia histórica; no como frontera paniense. **Arepa** continúa geolocalizada en Ushuaia. Se incluye importador específico para el ejido municipal oficial de IDE Tierra del Fuego. La región permanece sin contorno hasta obtener y verificar los datos oficiales.
- **Atlántida** sigue sin polígono aprobado; el **Sáhara Occidental** se indica como *Territorio en negociaciones*.
- Los nombres que aparecen en el mapa de capitales son **exclusivamente panienses**.

**Importante:** “exacto” significa que las líneas de las tres agrupaciones coinciden con las unidades administrativas que proporciona el conjunto fuente empleado. **La composición política de las regiones es una propuesta de ficción**, no una decisión institucional ratificada ni un límite estatal reconocido. Tampoco implica que los datos fuente de 2007/2018 sean las últimas demarcaciones oficiales.

## Sustituir en tu web

Copiar estas rutas del ZIP a tu web:

```text
src/pages/TerritorialDivisions.tsx
src/pages/TerritorialDivisions.css
public/atlas/                         # toda la carpeta
```

No tienes que cambiar la ruta de la página. Si ya tenías la v2.1, sustituye ambos componentes y **toda** la carpeta `public/atlas/`, ya que el componente espera dos GeoJSON nuevos.

CARTO sigue siendo opcional; en `.env.local`:

```dotenv
VITE_CARTO_BASEMAPS_KEY=TU_CLAVE_CARTO
```

Como cualquier clave enviada a un navegador es pública, **restríngele los dominios** desde el proveedor. Sin clave el atlas usa el fondo de relieve alternativo.

## Estructura cartográfica principal

```text
public/atlas/regiones.geojson           # 3 AND + Pretzel + Torroella: cinco features
public/atlas/subdivisiones.geojson      # las siete parroquias originales reales
public/atlas/contexto_fueguino.geojson  # provincial antigua, línea contextual sin relleno
public/atlas/capitales.geojson          # seis capitales panienses
public/atlas/especiales.geojson         # Atlántida, negociación y referencia Medas
public/atlas/estado_delimitacion_v22.json
public/atlas/{carreteras,ferrocarriles,aeropuertos,estaciones,puertos,otros}.geojson
```

No se incorporan estaciones, carreteras, aeropuertos o trenes inventados. Estos elementos pueden agregarse posteriormente a sus propios FeatureCollection reales, usando `[longitud, latitud]` en WGS84. Se mantiene el importador de carreteras de la versión anterior.

## Generar y validar desde las fuentes incorporadas

```bash
python -m pip install shapely requests
python scripts/generate_data.py
python scripts/validate_data.py
```

`generate_data.py` regenera primero los datos fuente incluidos en el paquete y después agrupa las regiones y actualiza los metadatos de la v2.2. **Regenerar sobrescribe las capas de regiones**, así que importa costas/eji​​do **después** de generar.

### Importar islas Medas reales (requiere conexión)

```bash
python scripts/importar_islas_medas_osm.py
python scripts/validate_data.py
```

- Lee costa insular mediante **Overpass** con referencia específica a Meda Gran (OpenStreetMap way 4791233).
- Solo añade anillos cerrados y geométricamente válidos; exige que **ChinPan quede dentro de alguna de las islas**.
- Si la consulta no devuelve datos correctos, termina con error y **no modifica el GeoJSON**. La precisión depende de la cartografía OSM, bajo licencia ODbL.
- Si el endpoint predeterminado no responde, se puede pasar `--endpoint` con otro intérprete público de Overpass.

### Importar ejido municipal Ushuaia (requiere conexión)

```bash
python scripts/importar_ejido_ushuaia.py
python scripts/validate_data.py
```

- Busca en el WFS oficial de **Infraestructura de Datos Espaciales de Tierra del Fuego** las capas de ejido/municipio disponibles en ese servidor.
- Solo incorpora una geometría **válida y etiquetada Ushuaia** que contenga la posición de **Arepa**. No la confunde con la provincia completa.
- Si no hay una capa accesible o el servidor requiere autenticación, aborta y deja la región sin polígono.

Los dos importadores son herramientas de incorporación verificable, **no promesas de que las fuentes vayan a estar siempre disponibles**. Para un despliegue serio se deben versionar en Git los GeoJSON tras importarlos y pasar la validación.

## Fuentes

- Andorra ADM1: https://github.com/robit-man/tiny-atlas/blob/main/elevation_model/geojson/ADM1/AND.geojson (derivado de geoBoundaries, ADM1 2007).
- Govern d'Andorra, cartografía oficial actual para contrastar: https://www.ideandorra.ad/geodades/index.jsp?lang=es
- Pretzel, municipios franceses: https://github.com/gregoiredavid/france-geojson (IGN Admin Express 2018).
- Torroella de Montgrí, geometría catalana generalizada: https://github.com/sirisacademic/catalonia-cartography/blob/master/cat-municipis.json; catastro administrativo actualizado ICGC: https://www.icgc.cat/es/Geoinformacion-y-mapas/Datos-y-productos/Geoinformacion-cartografica/Divisiones-administrativas
- Meda Gran: https://www.openstreetmap.org/way/4791233 (ODbL).
- Ejido municipal Ushuaia: https://ide.tierradelfuego.gob.ar/descargas/; WFS en https://tiles.tierradelfuego.gob.ar/geoserver/ows
- Cartografía provincial vieja (solo contexto): https://github.com/robit-man/tiny-atlas/blob/main/elevation_model/geojson/ADM1/ARG.geojson

**Pendiente para una v2.3:** incorporar la costa insular desde OSM y el ejido municipal de Ushuaia desde la IDE en un entorno con conectividad y comprobar los derechos/licencias de las capas oficiales más recientes.
