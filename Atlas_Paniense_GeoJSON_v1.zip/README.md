# ESTADO PANIENSE · Atlas Territorial v1.0

Implementación para el componente `src/pages/TerritorialDivisions.tsx` existente de una web **React + TypeScript + React Leaflet + Vite**.

## Instalación

1. Copia `src/pages/TerritorialDivisions.tsx` y `src/pages/TerritorialDivisions.css` dentro de tu proyecto, sustituyendo el componente antiguo.
2. Copia la carpeta `public/atlas/` completa a la carpeta `public/` de tu proyecto. **No** metas los GeoJSON en `src/` ni cambies las rutas sin actualizar el `fetch`.
3. Mantén las dependencias `react`, `react-leaflet`, `leaflet`, `@types/leaflet`, `@types/geojson` y tus componentes `Header`, `Footer`. Ejemplo: `npm install react-leaflet leaflet && npm install -D @types/leaflet @types/geojson`.
4. Abre la ruta web que ya apuntaba a `TerritorialDivisions`. En la pestaña de red deberían cargar los seis archivos `/atlas/*.geojson` con HTTP 200.
5. Las banderas son opcionales: el componente conserva las rutas `/Maps/Pimbo.png`, `/Maps/Croissant.png`, `/Maps/Baguette.png`, `/Maps/Pretzel.png`, `/Maps/Sin Glúten.png`, `/Maps/Pan Plano-Arepa.png` y `/Maps/Atlántida.png`.

## GeoJSON incluido

| Archivo | Geometría | Contenido |
| --- | --- | --- |
| `regiones.geojson` | Polygon y MultiPolygon | **Seis** regiones delimitadas, incluyendo las tres de Andorra; Atlántida sin límite por ahora |
| `capitales.geojson` | Point | Las **seis** capitales ya acordadas; la posición de Pantopía es provisional |
| `especiales.geojson` | Point | Referencias para Atlántida (cerca de Belgrano II) y Sáhara Occidental en negociaciones |
| `carreteras.geojson` | LineString | Tres corredores **ESQUEMÁTICOS, NO reales** para empezar a planificar |
| `ferrocarriles.geojson` | FeatureCollection vacía | Preparado para añadir vías reales o propuestas |
| `infraestructuras.geojson` | FeatureCollection vacía | Preparado para aeropuertos, estaciones, puertos, hospitales, monumentos, recursos |

**GeoJSON usa coordenadas `[longitud, latitud]` WGS84 (EPSG:4326). Leaflet Marker recibe `[latitud, longitud]`.**

## Acuerdos territoriales (no modificar accidentalmente)

| Región | Capital | Emplazamiento base |
| --- | --- | --- |
| Baguette | Pantopía | Zona centro-sur de Andorra. **Capital estatal y regional** |
| Pimbo | Pimbolandia | Ordino |
| Croissant | Vila Croissant | Meritxell |
| Pretzel | Pretzelópolis | Bayona (Francia) |
| Sin Glúten | ChinPan | Meda Gran, islas Medas (Girona) |
| Pan Plano/Arepa | Arepa | Ushuaia, Tierra del Fuego |
| Atlántida | **Sin determinar** | Territorio de ultramar, límites **pendientes** |
| Sáhara Occidental | — | **Territorio en negociaciones**, no una región ratificada |

> **Aviso cartográfico**: la imagen previa y las capturas de mapas proporcionan la intención política, pero no bastan para determinar fronteras precisas. Los GeoJSON son **borradores ilustrativos**: el contorno andorrano, la costa vasca, el litoral de Girona y Tierra del Fuego aún requieren cartografía vectorial verificada. No se presentan como datos oficiales ni como fronteras actuales de países reales. Tampoco son rutas para navegar.

## Modos

- **Político**: OpenStreetMap claro + límites coloreados (alto contraste).
- **Geográfico**: OpenTopoMap + fronteras semitransparentes para ver el terreno.
- **GTA V mode**: mapa OSM oscurecido y desaturado mediante CSS, límites destacados y corredores amarillos discontinuos. **Estética inspirada**, sin utilizar assets originales de GTA.

Los tres modos conservan los GeoJSON, las capitales, la selección de región, el ajuste automático del zoom y las capas intercambiables. Las teselas requieren conexión a internet. Muestra las atribuciones de OSM y OpenTopoMap.

## ¿Cómo agregar infraestructuras?

Edita `public/atlas/infraestructuras.geojson`, añadiendo `Feature` con `geometry: { "type": "Point", "coordinates": [lon,lat] }`. Valores para `properties.categoria`: `aeropuerto`, `estacion_tren`, `puerto`, `hospital`, `monumento`, `recurso`, `ciudad`. Añade `properties.region_id`, `properties.nombre`, `properties.estado` (`real`, `propuesto`, `en_construccion` o `ficticio`) y opcionalmente `properties.nota`.

Para trenes, utiliza `public/atlas/ferrocarriles.geojson`: Features `LineString` `[ [lon,lat], ...]` con `nombre`, `estado`, `ancho_via`, `tipo_linea` y `operador` si proceden. Carreteras de igual forma en `carreteras.geojson`, con `clase` (`autopista`, `principal`, `secundaria`, `pista`, `corredor_propuesto`), `referencia`, `sentido` y `estado`. Todo esto son campos extensibles; el visor muestra actualmente nombre y nota de la línea.

**Para trazados reales**, importa datos vectoriales georreferenciados de OpenStreetMap o de la administración correspondiente, respetando su licencia. No dibujes líneas rectas entre poblaciones y las llames autopistas construidas.

## Precisión: refinar Andorra

El script `scripts/refinar_andorra.py` permite sustituir la silueta andorrana de demostración por un contorno GeoJSON basado en datos externos, sin tocar las otras regiones:

```bash
pip install shapely requests
python scripts/refinar_andorra.py --descargar
# o con una capa administrativa ya descargada:
python scripts/refinar_andorra.py --entrada mis_parroquias_andorra.geojson
```

Obtiene los límites reales del país como **unión** de los 7 polígonos parroquiales del GeoJSON de entrada; recorta los tres polígonos políticos de nuestra propuesta sin huecos ni solapamientos. `scripts/plantillas_andorra.geojson` define los repartos interiores y puede ajustarse iterativamente; **esas líneas siguen siendo ficticias**. Guarda una copia de seguridad del GeoJSON anterior. geoBoundaries requiere atribución y su fuente original de Andorra está fechada en 2007. Es preferible usar, cuando esté disponible, la cartografía de límites parroquiales del Govern d'Andorra. Si utilizas geoBoundaries, añade su atribución al mapa o pie de página.

Para el resto de territorios necesitamos delimitar municipio/parroquia, costa, islas y fronteras acordadas, idealmente mediante GeoJSON de sus administraciones locales. Atlántida y el Sáhara no se convierten en polígonos soberanos sin acuerdo explícito.

## Qué queda pendiente

- Ratificar polígonos definitivos de las regiones (y trazado más preciso de Girona y Tierra del Fuego).
- Escoger los límites de Atlántida y definir su capital (si procede).
- Fijar las coordenadas definitivas de Pantopía.
- Importar carreteras existentes desde datos geográficos verificables y diseñar corredores de nueva construcción por separado.
- Añadir puntos concretos de aeropuertos, estaciones, puertos, pasos fronterizos, centros sanitarios y monumentos.
- En una fase posterior, sincronizar las colecciones de GeoJSON con una tabla espacial PostGIS/Supabase; **esta versión no sobreescribe la tabla `puntos_interes` existente** para evitar mezclar antiguas capitales con el nuevo reparto.

Fuentes de mapas de base: [OpenStreetMap](https://www.openstreetmap.org/copyright), [OpenTopoMap](https://opentopomap.org/). Límites a contrastar: [cartografía del Govern d'Andorra](https://www.ideandorra.ad/geodades/index.jsp?lang=es), [geoBoundaries](https://www.geoboundaries.org/api.html).
