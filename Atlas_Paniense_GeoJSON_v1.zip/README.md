# ESTADO PANIENSE · ATLAS CARTOGRÁFICO v2.0

Sustitución para **React / TypeScript / Vite / React-Leaflet** del antiguo `TerritorialDivisions.tsx`.

## Qué se corrigió de verdad

- **Polígonos administrativos reales como GeoJSON estático**: siete parroquias de Andorra (geoBoundaries), diez municipios costeros de Francia (IGN Admin Express) y perímetro histórico publicado de Tierra del Fuego (geoBoundaries). **No hay coordenadas trazadas a mano**. Los originales se han redondeado a cinco decimales, sin añadir vértices imaginarios. Se incluyen fuentes, año y licencia.
- **Adscripción paniense separada del dato real**: no se afirma que esas parroquias sean oficialmente regiones de un Estado real. La agrupación constituye una propuesta política de ficción pendiente de ratificación.
- **El nombre visible de las capitales es exclusivamente paniense**. Las tres teselas de base no incorporan etiquetas urbanas: CARTO Light No Labels, Esri World Shaded Relief, CARTO Dark No Labels. Las capitales se rotulan con el GeoJSON `capitales.geojson`, no con el nomenclátor externo.
- **Tres modos cartográficos** con fondo y estilización genuinamente distintos. La leyenda institucional, barra lateral y fichas han sido rediseñadas de forma responsive.
- **Capas independientes**: fronteras, capitales, carreteras, ferrocarriles, aeropuertos, estaciones, puertos, otros equipamientos y especiales. GeoJSON vacío no equivale a infraestructuras existentes.
- **Descarga directa** del GeoJSON, filtrado territorial, visor multi-territorio, barra de escala, y extensibilidad.

## Instalación

1. Copia `src/pages/TerritorialDivisions.tsx` y `TerritorialDivisions.css` sobre los actuales.
2. Copia `public/atlas/` en la carpeta `public/atlas/` de la web.
3. Conserva `Header` y `Footer` de tu web; el componente los importa desde `../components/`.
4. Instala dependencias (si te faltan):
   ```bash
   npm install leaflet react-leaflet
   npm install -D @types/leaflet @types/geojson
   ```
5. Ejecuta el dev server y abre la ruta existente.
6. Para reconstruir desde las coordenadas de fuentes reales *incluidas en el paquete* (sin requerir internet):
   ```bash
   pip install shapely
   python scripts/generate_data.py
   python scripts/validate_data.py
   ```

## Estructura

```text
src/pages/TerritorialDivisions.tsx
src/pages/TerritorialDivisions.css
public/atlas/
  regiones.geojson                # AND + FRA + ARG (18 piezas reales)
  parroquias_referencia.geojson   # las 7 unidades andorranas reales
  capitales.geojson               # solo nombres panienses
  especiales.geojson              # Atlántida / Sáhara / referencia Medas
  carreteras.geojson              # vacío sin importar datos OSM
  ferrocarriles.geojson           # vacío
  aeropuertos.geojson             # vacío
  estaciones.geojson              # vacío
  puertos.geojson                 # vacío
  otros.geojson                   # vacío
  INFO_fuentes.json
scripts/
  generate_data.py
  validate_data.py
  importar_carreteras_osm.py
```

## Delimitación territorial actual: hecho y pendiente

| Unidad | Estado geométrico | Capital visible |
|--|--|--|
| Pimbo | Ordino, La Massana y Sant Julià de Lòria (polígonos reales, agrupación paniense provisional) | Pimbolandia |
| Baguette | Andorra la Vella y Escaldes-Engordany (polígonos reales, agrupación provisional) | **Pantopía** (también capital del Estado Paniense) |
| Croissant | Canillo y Encamp (polígonos reales, agrupación provisional) | Vila Croissant |
| Pretzel | Diez municipios de litoral vascofrancés; geometrías reales, selección provisional | Pretzelópolis |
| Sin Glúten | **NO delimitado todavía**: islas Medas y sector de Girona siguen necesitando una decisión precisa | ChinPan (isla, punto aproximado) |
| Pan Plano / Arepa | Sector cartográfico real histórico de la provincia argentina Tierra del Fuego; **el punto de Ushuaia queda fuera del perímetro simplificado**, pendiente de actualización | Arepa (Ushuaia) |
| Atlántida | **NO delimitado**: no se inventa un polígono antártico | Sin capital acordada |
| Sáhara Occidental | **Territorio en negociaciones**, sin adscripción a región paniense | — |

### ¿Cómo se asignaron las parroquias?

La versión 1 tenía geometrías inventadas. La versión 2 adopta una **agrupación parroquial 3/2/2**, georreferenciada, coherente con los tres ejes de la imagen pero **no idéntica** al dibujo simbólico inicial (el dibujo cortaba parroquias). Si el trazado exacto del boceto es imprescindible, haría falta aprobar cada nuevo tramo de frontera por separado, apoyado en información espacial real, **sin afirmar falsamente que es un límite administrativo existente**.

### Por qué faltan algunos polígonos

Sin Glúten indica «las islas Medas y una parte de Girona» sin precisar cuál parte. Sin un perímetro ratificado sería incorrecto presentar un polígono arbitrario como preciso. Para la parte terrestre puede elegirse por ejemplo Torroella de Montgrí, recuperando su límite administrativo real desde el ICGC. El recinto insular necesita además la geometría de costa específica de Meda Gran y los demás islotes.

Atlántida tampoco tiene límites aprobados: se muestra únicamente un marcador de referencia polar. El Sáhara Occidental no figura coloreado como región ratificada.

## Importar carreteras reales de Andorra

En una máquina con internet:

```bash
pip install requests shapely
python scripts/importar_carreteras_osm.py
```

Obtiene `way` de OSM/Overpass, recorta las geometrías sobre el perímetro geográfico real de las siete parroquias y escribe `public/atlas/carreteras.geojson`. Las fuentes OSM están bajo ODbL, respeta la atribución. Importación voluntaria para no depender de proveedores en cada visita a la web.

## Esquema para nuevas infraestructuras

Las carreteras, ferrocarriles y demás objetos se escriben como `FeatureCollection`, cada feature tiene `properties.id`, `nombre`, `region_id`, `categoria`, `estado`, `source`, y `geometry` WGS84. Para vías, `geometry.type = "LineString"` con `[[lon,lat], ...]`, **nunca rectas artificiales entre dos capitales presentadas como reales**. Para aeropuertos, estaciones y puertos, `geometry.type = "Point"` con `[lon,lat]`.

Ejemplo de infraestructura futura: `{ "type":"Feature", "properties":{"id":"estacion-001", "nombre":"Estación Paniense 001", "categoria":"estacion", "region_id":"baguette", "estado":"propuesto", "source":"proyecto propio"}, "geometry":{"type":"Point", "coordinates":[1.5218,42.5063]} }`. Es solo un ejemplo de formato, **no se incluye como estación existente**.

**Importante:** No se han tocado tus tablas Supabase, ni inventado aeropuertos, ni incorporado etiquetas reales de ciudades en el fondo.

## Procedencia y créditos

- [geoBoundaries API (Andorra ADM1 y Argentina ADM1)](https://www.geoboundaries.org/api.html): versiones administrativas históricas indicadas en `INFO_fuentes.json`.
- [gregoiredavid/france-geojson: IGN Admin Express 2018](https://github.com/gregoiredavid/france-geojson): comunas francesas, Licence Ouverte 2.0.
- [ICGC / Catalunya - Municipis](https://agportal.sig.gencat.cat/server/rest/services/Hosted/Municipis_1000000/FeatureServer/0): fuente para una futura delimitación de Girona, no integrada todavía.
- [OpenStreetMap](https://www.openstreetmap.org/copyright), [CARTO](https://carto.com/attributions) y [Esri](https://www.esri.com): cartografía base. La atribución aparece dentro del mapa, y las fuentes en el pie de página.
