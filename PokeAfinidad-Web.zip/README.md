# PokéAfinidad

Web de prueba de afinidad con organizaciones del universo Pokémon, desarrollada como un único archivo HTML con CSS y JavaScript integrados.

## Cómo utilizarla

Abre `index.html` en cualquier navegador moderno o súbelo a cualquier alojamiento estático (GitHub Pages, Netlify, Vercel, etc.). No se necesita instalación, compilación, cuenta, base de datos ni servidor.

## Funcionalidades

- Inicio con dos modalidades: rápido (14 preguntas) y completo (28 preguntas con importancia configurable).
- 20 organizaciones con descripciones y filtrado por tipo.
- Respuestas de 1 a 5, saltar, retroceder, navegación por teclado, progreso y guardado local para continuar.
- Resultado con clasificación completa y afinidad desglosada en siete temas.
- Compartir el texto del resultado cuando el navegador lo permita.
- Diseño adaptativo, accesibilidad básica, contraste y reducción de movimiento.

## Metodología

Cada facción tiene una postura interpretativa entre 1 y 5 por pregunta, obtenida a partir de un perfil temático editable en el propio HTML y de algunas excepciones específicas. No son posturas canónicas ni oficiales.

Para cada respuesta, la puntuación de coincidencia es `((4 - abs(respuesta - postura)) / 4) ** 2`. Se promedia ponderando por importancia (1–5 en modo completo, 3 en rápido) y convicción de la respuesta (`0.5 + abs(respuesta-3)*0.25`). Las preguntas saltadas no se cuentan. El porcentaje final se redondea entre 0 y 100. No representa una probabilidad científica.

Para modificar preguntas u organizaciones, edita los arrays `questions` y `factions` en la etiqueta `<script>` de `index.html`.

## Nota legal y de privacidad

Proyecto independiente y no oficial para fans, sin afiliación con Nintendo, Game Freak ni The Pokémon Company. Todos los nombres y conceptos propios de Pokémon pertenecen a sus respectivos titulares.

Los datos del test permanecen en el navegador: se guardan en `localStorage` con la clave `pokeafinidad:v1` para permitir reanudar; no se envían a ningún servidor.
